# Lab7_screenshot

陈逸飞 12010502

## EX1

![](/Users/ericchen/Desktop/cppLab/Lab7/Lab7_code/EX1.png)



## EX2

![](/Users/ericchen/Desktop/cppLab/Lab7/Lab7_code/Ex2.png)

