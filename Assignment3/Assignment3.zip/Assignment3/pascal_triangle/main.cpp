#include "pascal.h"

int main()
{
       
    cout << pascal(0, 0) << endl;    // should return 1 
    cout << pascal(0, 5) << endl;   // should return 0 
    cout << pascal(3, 2) << endl;   // should return 3 
    cout << pascal(4, 2) << endl;   // should return 6

    return 0;
}