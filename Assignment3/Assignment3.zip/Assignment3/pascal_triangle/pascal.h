#ifndef PASCAL_H
#define PASCAL_H

#include <iostream>

using namespace std;

/**
 * @brief 
 * 
 * @param row the row of searched element
 * @param column the column of searched element
 * @return ** int the value of searched element
 */

int pascal(int row, int column);

#endif