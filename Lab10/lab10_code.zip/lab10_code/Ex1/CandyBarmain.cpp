#include "CandyBar.h"

int main()
{
    CandyBar candybar("Bulle Marphi",4.5,230);
    candybar.CandyBar::setCandyBar();
    candybar.showCandyBar();
    return 0;

}