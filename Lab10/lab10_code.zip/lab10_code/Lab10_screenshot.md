# Lab10_screenshot

## Ex1

![](/Users/ericchen/Desktop/cppLab/Lab10/lab10_code/Ex1.png)



## Ex2

![](/Users/ericchen/Desktop/cppLab/Lab10/lab10_code/Ex2.png)

