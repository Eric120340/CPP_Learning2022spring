#include <iostream>
#include "stock02.h"
using namespace std;
int main(){
    Stock stock("ERIC LIMITED");
    cout << stock;
}