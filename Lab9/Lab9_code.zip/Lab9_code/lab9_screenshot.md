# lab9_screenshot

陈逸飞12010502

## EX1

![](/Users/ericchen/Desktop/cppLab/Lab9/Lab9_code/EX1.png)



## EX2

![](/Users/ericchen/Desktop/cppLab/Lab9/Lab9_code/EX2.png)

