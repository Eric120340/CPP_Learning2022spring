# Lab15_Screenshot

12010502

陈逸飞

## EX1

![](/Users/ericchen/Desktop/cppLab/Lab15/Ex1.jpg)

## EX2

![](/Users/ericchen/Desktop/cppLab/Lab15/Ex2.jpg)

