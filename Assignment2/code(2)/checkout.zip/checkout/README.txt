root-data
possible tree elements
all elements inserted into bst